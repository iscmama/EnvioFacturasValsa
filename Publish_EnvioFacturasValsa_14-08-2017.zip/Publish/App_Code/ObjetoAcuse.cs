﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descripción breve de ObjetoAcuse
/// </summary>
public class ObjetoAcuse
{
    public String IdFactura;
    public String Archivo;
    public String IdUsuario;
    public int Numero;
    public String NumeroString;
}