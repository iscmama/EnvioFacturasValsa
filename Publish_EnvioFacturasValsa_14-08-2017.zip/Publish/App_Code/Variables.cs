﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descripción breve de Variables
/// </summary>
public class Variables
{
	public Variables()
	{
        
	}

    public String Log;
    public String Fecha;
    public String Inicio;
    public String Modulo;
    public String Fin;
    public String Descripcion;
}