﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descripción breve de ObjetoClientes
/// </summary>
public class ObjetoClientes
{
    public String RFC;
    public String RazonSocial;
}